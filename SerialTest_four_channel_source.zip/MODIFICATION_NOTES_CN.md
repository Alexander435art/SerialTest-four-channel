# 本次修改说明

本次依据用户提供的蓝牙串口上位机运行界面截图，在先前上传的 SerialTest Qt 源码基础上修改绘图模块。

## 保留内容

- 保留原有 PlotTab 底部工具栏和控件顺序。
- 保留“启动/Enable”“显示最新数据/Show latest”“清空/Clear”“X 轴类型”“数据项数”“图例”“适应 X 轴”“适应 Y 轴”“高级”“光标”等功能。
- 数据项数在 Count/Time 模式固定为 4；First data 模式固定为 5（X + 4 个通道），控件仍显示在工具栏上。
- 保留 SerialTest 原有串口、蓝牙、数据接收、发送、保存、文件传输等模块，不修改这些通信逻辑。

## 绘图改动

- 将一个包含多条曲线的 QCustomPlot 替换为 2×2 的四个 QCustomPlot。
- CH1～CH4 各自只有一条曲线，各自拥有独立 X/Y 轴范围。
- 每个窗口可独立缩放、平移和双击坐标轴自动适配。
- 绘图区滚轮同时缩放当前窗口的 X/Y 轴；在 X 轴或 Y 轴上滚轮只缩放该轴。
- 底部“适应 X 轴”和“适应 Y 轴”按钮仍作用于四个窗口。
- “显示最新数据”模式下，每个窗口分别保存自己的 X 轴显示宽度。
- 默认线条颜色：蓝、红橙、绿、深紫；线宽 2.4 px。

## 数据帧格式

- X 轴为 Count 或 Time：每帧 `CH1,CH2,CH3,CH4`。
- X 轴为 First data：每帧 `X,CH1,CH2,CH3,CH4`。

## 编译提示

本压缩包提供的是修改后的 Qt/C++ 源码，不是已经编译验证的 Windows EXE。当前执行环境没有 Qt 5 开发套件和 qmake，不能在这里完成 Windows 编译验证。

原始工程使用 Qt 5 + MinGW。项目的 `src/qcustomplot.h` 已包含，但原始压缩包没有包含 `qcustomplot.cpp`；按原项目 README，需下载 QCustomPlot 2.1.1 源码包，将 `qcustomplot.cpp` 和匹配版本的 `qcustomplot.h` 放入 `src` 后再用 Qt Creator 打开 `src/SerialTest.pro` 构建。若本机已安装兼容的 QCustomPlot 库，也可按 `.pro` 中的库配置构建。

请备份并保留当前运行目录中的 `preference.ini`。新 EXE 首次运行时将其放在 EXE 同目录，以保留串口历史、蓝牙历史和原有绘图设置。建议先在测试副本中编译和运行，不要直接覆盖当前可用的 EXE。
