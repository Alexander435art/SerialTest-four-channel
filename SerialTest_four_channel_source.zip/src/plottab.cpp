#include "plottab.h"
#include "ui_plottab.h"

#include "legenditemdialog.h"

#include <QGridLayout>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QLayoutItem>
#include <QSizePolicy>

namespace
{
const QColor kPlotColors[4] = {
    QColor("#0072B2"), // blue
    QColor("#D55E00"), // vermilion
    QColor("#009E73"), // green
    QColor("#7A3E9D")  // deep purple
};

const qreal kPlotLineWidth = 2.4;
}

PlotTab::PlotTab(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PlotTab)
{
    ui->setupUi(this);

    // Replace the original single plot with four independent plot panels.
    m_plotGridWidget = new QWidget(this);
    m_plotGridWidget->setObjectName("plotGridWidget");
    m_plotGridWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QGridLayout *gridLayout = new QGridLayout(m_plotGridWidget);
    gridLayout->setContentsMargins(2, 2, 2, 2);
    gridLayout->setHorizontalSpacing(6);
    gridLayout->setVerticalSpacing(6);

    QLayoutItem *oldPlotItem = ui->verticalLayout->replaceWidget(ui->qcpWidget, m_plotGridWidget);
    delete oldPlotItem;
    ui->qcpWidget->hide();

    for(int i = 0; i < PlotCount; ++i)
    {
        m_plotGroups[i] = new QGroupBox(tr("CH%1").arg(i + 1), m_plotGridWidget);
        m_plotGroups[i]->setObjectName(QString("plotGroup%1").arg(i + 1));
        QVBoxLayout *groupLayout = new QVBoxLayout(m_plotGroups[i]);
        groupLayout->setContentsMargins(5, 8, 5, 5);
        groupLayout->setSpacing(2);

        m_plots[i] = new MyCustomPlot(m_plotGroups[i]);
        m_plots[i]->setObjectName(QString("qcpWidgetCH%1").arg(i + 1));
        m_plots[i]->setMinimumSize(180, 130);
        m_plots[i]->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        m_plots[i]->setToolTip(tr("Wheel over the X or Y axis to zoom that axis; drag the axis to pan; double-click an axis to fit it. Wheel over the plot area to zoom both axes."));
        groupLayout->addWidget(m_plots[i]);

        gridLayout->addWidget(m_plotGroups[i], i / 2, i % 2);
        gridLayout->setRowStretch(i / 2, 1);
        gridLayout->setColumnStretch(i % 2, 1);
    }

    // Keep the original toolbar visible. The data-count control is retained
    // for visual continuity with the user's current interface; its value is
    // constrained to 4 (or 5 when the first field is the X coordinate).

    doubleRegex = new QRegularExpression("-?\\d*\\.?\\d+"); // for +xxxxx and xxxxx. , just get xxxxx
    doubleRegex->optimize();
    on_plot_advancedBox_stateChanged(Qt::Unchecked); // hide
}

PlotTab::~PlotTab()
{
    delete ui;
}

void PlotTab::initSettings()
{
    settings = MySettings::defaultSettings();
    loadPreference();

    connect(ui->plot_enaBox, &QCheckBox::clicked, this, &PlotTab::savePlotPreference);
    connect(ui->plot_latestBox, &QCheckBox::clicked, this, &PlotTab::savePlotPreference);
    connect(ui->plot_XTypeBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PlotTab::savePlotPreference);
    connect(ui->plot_legendCheckBox, &QCheckBox::clicked, this, &PlotTab::savePlotPreference);
    connect(ui->plot_tracerCheckBox, &QCheckBox::clicked, this, &PlotTab::savePlotPreference);
    connect(ui->plot_frameSpTypeBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PlotTab::savePlotPreference);
    connect(ui->plot_frameSpEdit, &QLineEdit::editingFinished, this, &PlotTab::savePlotPreference);
    connect(ui->plot_dataSpTypeBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PlotTab::savePlotPreference);
    connect(ui->plot_dataSpEdit, &QLineEdit::editingFinished, this, &PlotTab::savePlotPreference);
    connect(ui->plot_clearFlagTypeBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PlotTab::savePlotPreference);
    connect(ui->plot_clearFlagEdit, &QLineEdit::editingFinished, this, &PlotTab::savePlotPreference);
    connect(ui->plot_plotStyleBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &PlotTab::savePlotPreference);
}

void PlotTab::setReplotInterval(int msec)
{
    if(m_dataProcessTimer)
        m_dataProcessTimer->setInterval(msec);
}

void PlotTab::initQCP()
{
    plotBuf = new QString();
    m_dataProcessTimer = new QTimer(this);
    plotTime = QTime::currentTime();
    plotCounter = 0;
    plotTimeTicker->setTimeFormat("%h:%m:%s.%z");
    plotTimeTicker->setTickCount(5);

    connect(m_dataProcessTimer, &QTimer::timeout, this, &PlotTab::processData);
    m_dataProcessTimer->setInterval(20);
    m_dataProcessTimer->start();

    for(int i = 0; i < PlotCount; ++i)
    {
        MyCustomPlot *plot = m_plots[i];
        plotDefaultTickers[i] = plot->xAxis->ticker();
        plotXAxisWidths[i] = plot->xAxis->range().size();

        plot->axisRect()->setupFullAxesBox(true);
        plot->axisRect()->setRangeDrag(Qt::Horizontal | Qt::Vertical);
        plot->axisRect()->setRangeZoom(Qt::Horizontal | Qt::Vertical);
        const QList<QCPAxis*> horizontalAxes = QList<QCPAxis*>() << plot->xAxis << plot->xAxis2;
        const QList<QCPAxis*> verticalAxes = QList<QCPAxis*>() << plot->yAxis << plot->yAxis2;
        plot->axisRect()->setRangeDragAxes(horizontalAxes, verticalAxes);
        plot->axisRect()->setRangeZoomAxes(horizontalAxes, verticalAxes);
        plot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectLegend | QCP::iSelectPlottables);
        plot->legend->setSelectableParts(QCPLegend::spItems);
        plot->legend->setVisible(false);

        QCPGraph *graph = plot->addGraph();
        QPen graphPen(kPlotColors[i]);
        graphPen.setWidthF(kPlotLineWidth);
        graph->setPen(graphPen);
        graph->setName(QString("CH%1").arg(i + 1));
        graph->setSelectable(QCP::stWhole);

        m_plotTracers[i] = new QCPItemTracer(plot);
        m_plotTracers[i]->setStyle(QCPItemTracer::tsCrosshair);
        m_plotTracers[i]->setBrush(Qt::red);
        m_plotTracers[i]->setInterpolating(false);
        m_plotTracers[i]->setGraph(graph);
        m_plotTracers[i]->setVisible(false);

        m_plotTexts[i] = new QCPItemText(plot);
        m_plotTexts[i]->setPositionAlignment(Qt::AlignTop | Qt::AlignLeft);
        m_plotTexts[i]->setTextAlignment(Qt::AlignLeft);
        m_plotTexts[i]->position->setType(QCPItemPosition::ptAxisRectRatio);
        m_plotTexts[i]->position->setCoords(0.01, 0.01);
        m_plotTexts[i]->setPen(QPen(Qt::black));
        m_plotTexts[i]->setPadding(QMargins(2, 2, 2, 2));
        m_plotTexts[i]->setVisible(false);

        connect(plot, &QCustomPlot::legendDoubleClick, this, &PlotTab::onQCPLegendDoubleClick);
        connect(plot, &QCustomPlot::legendClick, this, &PlotTab::onQCPLegendClick);
        connect(plot, &QCustomPlot::axisDoubleClick, this, &PlotTab::onQCPAxisDoubleClick);
        connect(plot, &QCustomPlot::mousePress, this, &PlotTab::onQCPMousePress);
        connect(plot, &QCustomPlot::mouseRelease, this, &PlotTab::onQCPMouseRelease);
        connect(plot->xAxis, QOverload<const QCPRange&>::of(&QCPAxis::rangeChanged), this, &PlotTab::onXAxisChangedByUser);

        plot->replot();
    }
}

int PlotTab::plotIndex(QCustomPlot *plot) const
{
    for(int i = 0; i < PlotCount; ++i)
    {
        if(m_plots[i] == plot)
            return i;
    }
    return -1;
}

QCustomPlot *PlotTab::plotFromSender() const
{
    return qobject_cast<QCustomPlot*>(sender());
}

void PlotTab::onQCPLegendDoubleClick(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent* event)
{
    Q_UNUSED(legend)
    if((event->button() & Qt::LeftButton) == 0 || item == nullptr)
        return;

    QCustomPlot *plot = plotFromSender();
    if(!plot)
        return;

    QCPPlottableLegendItem *plItem = qobject_cast<QCPPlottableLegendItem*>(item);
    if(!plItem)
        return;
    QCPAbstractPlottable* pl = plItem->plottable();
    if(pl->visible())
    {
        pl->setName("*" + pl->name());
        pl->setVisible(false);
    }
    else
    {
        QString oldName = pl->name();
        if(!oldName.isEmpty() && oldName[0] == '*')
            pl->setName(oldName.right(oldName.size() - 1));
        pl->setVisible(true);
    }
    plot->replot();
}

void PlotTab::onQCPLegendClick(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent* event)
{
    Q_UNUSED(legend)
    if((event->button() & Qt::RightButton) == 0 || item == nullptr)
        return;
    setGraphProperty(plotFromSender(), item);
}

void PlotTab::onQCPAxisDoubleClick(QCPAxis *axis)
{
    if(!axis)
        return;
    // Double-clicking an axis fits only that axis in only that channel's panel.
    axis->rescale(true);
    if(axis->parentPlot())
        axis->parentPlot()->replot();
}

void PlotTab::onQCPMousePress(QMouseEvent *event)
{
    QCustomPlot *plot = plotFromSender();
    QCPAbstractLegendItem* item = getLegendItemByPos(plot, event->pos());
    if(item == nullptr)
        return;
    longPressCounter[item] = event->timestamp();
}

void PlotTab::onQCPMouseRelease(QMouseEvent *event)
{
    QCustomPlot *plot = plotFromSender();
    QCPAbstractLegendItem* item = getLegendItemByPos(plot, event->pos());
    if(item == nullptr)
        return;
    ulong pressTimestamp = longPressCounter[item];
    ulong releaseTimestamp = event->timestamp();
    if(pressTimestamp != 0 && releaseTimestamp > pressTimestamp && releaseTimestamp - pressTimestamp > 700)
        setGraphProperty(plot, item);
    longPressCounter[item] = 0;
}

void PlotTab::onQCPMouseMoved(QMouseEvent *event)
{
    if(!ui->plot_tracerCheckBox->isChecked())
        return;
    QCustomPlot *plot = plotFromSender();
    int index = plotIndex(plot);
    if(index < 0)
        return;
    double x = plot->xAxis->pixelToCoord(event->pos().x());
    updateTracer(index, x);
}

void PlotTab::on_plot_dataNumBox_valueChanged(int arg1)
{
    changeGraphNum(arg1);
    longPressCounter.clear();
    savePlotPreference();
}

void PlotTab::changeGraphNum(int newNum)
{
    Q_UNUSED(newNum)
    // Four fixed panels are used. Each panel always owns exactly one channel graph.
}

void PlotTab::on_plot_clearButton_clicked()
{
    clearGraph();
    emit clearRxData();
}

void PlotTab::clearGraph()
{
    plotCounter = 0;
    plotTime = QTime::currentTime();
    for(int i = 0; i < PlotCount; ++i)
    {
        if(m_plots[i] && m_plots[i]->graphCount() > 0)
        {
            m_plots[i]->graph(0)->data()->clear();
            m_plots[i]->replot();
        }
    }
    if(plotBuf)
        plotBuf->clear();
}

void PlotTab::on_plot_legendCheckBox_stateChanged(int arg1)
{
    for(int i = 0; i < PlotCount; ++i)
    {
        m_plots[i]->legend->setVisible(arg1 == Qt::Checked);
        m_plots[i]->replot();
    }
}

void PlotTab::on_plot_advancedBox_stateChanged(int arg1)
{
    ui->plot_advancedWidget->setVisible(arg1 == Qt::Checked);
}

void PlotTab::updateTracer(int index, double x)
{
    if(index < 0 || index >= PlotCount || !m_plotTracers[index] || !m_plots[index]->graphCount())
        return;

    QCustomPlot *plot = m_plots[index];
    QCPItemTracer *tracer = m_plotTracers[index];
    tracer->setGraphKey(x);
    tracer->updatePosition();

    double xValue = tracer->position->key();
    double yValue = tracer->position->value();
    m_plotTexts[index]->setText(QString("CH%1\nX: %2\nY: %3").arg(index + 1).arg(xValue).arg(yValue));
    plot->replot();
}

void PlotTab::on_plot_tracerCheckBox_stateChanged(int arg1)
{
    bool visible = (arg1 == Qt::Checked);
    for(int i = 0; i < PlotCount; ++i)
    {
        if(visible)
            connect(m_plots[i], &QCustomPlot::mouseMove, this, &PlotTab::onQCPMouseMoved, Qt::UniqueConnection);
        else
            disconnect(m_plots[i], &QCustomPlot::mouseMove, this, &PlotTab::onQCPMouseMoved);

        m_plotTracers[i]->setVisible(visible);
        m_plotTexts[i]->setVisible(visible);
        m_plots[i]->replot();
    }
}

void PlotTab::on_plot_fitXButton_clicked()
{
    // The toolbar Fit X button fits the X range of all four panels.
    for(int i = 0; i < PlotCount; ++i)
    {
        m_plots[i]->xAxis->rescale(true);
        m_plots[i]->replot();
    }
}

void PlotTab::on_plot_fitYButton_clicked()
{
    // The toolbar Fit Y button fits the Y range of all four panels.
    for(int i = 0; i < PlotCount; ++i)
    {
        m_plots[i]->yAxis->rescale(true);
        m_plots[i]->replot();
    }
}

void PlotTab::on_plot_frameSpTypeBox_currentIndexChanged(int index)
{
    ui->plot_frameSpEdit->setVisible(index != 2 && index != 3);
    if(index == 0)
    {
        if(ui->plot_frameSpEdit->text().isEmpty())
            ui->plot_frameSpEdit->setText(plotFrameSeparator);
        else
            plotFrameSeparator = ui->plot_frameSpEdit->text();
    }
    else if(index == 1)
    {
        QByteArray newSp = QByteArray::fromHex(ui->plot_frameSpEdit->text().toLatin1());
        if(ui->plot_frameSpEdit->text() == "")
            ui->plot_frameSpEdit->setText(newSp.toHex(' '));
        else
            plotFrameSeparator = newSp;
    }
    else if(index == 2)
        plotFrameSeparator = "\r\n";
    else if(index == 3)
        plotFrameSeparator = "\n";
}

void PlotTab::on_plot_dataSpTypeBox_currentIndexChanged(int index)
{
    ui->plot_dataSpEdit->setVisible(index != 2 && index != 3);
    if(index == 0)
    {
        if(ui->plot_dataSpEdit->text().isEmpty())
            ui->plot_dataSpEdit->setText(plotDataSeparator);
        else
            plotDataSeparator = ui->plot_dataSpEdit->text();
    }
    else if(index == 1)
    {
        QByteArray newSp = QByteArray::fromHex(ui->plot_dataSpEdit->text().toLatin1());
        if(ui->plot_dataSpEdit->text() == "")
            ui->plot_dataSpEdit->setText(newSp.toHex(' '));
        else
            plotDataSeparator = newSp;
    }
    else if(index == 2)
        plotDataSeparator = "\r\n";
    else if(index == 3)
        plotDataSeparator = "\n";
}

void PlotTab::on_plot_clearFlagTypeBox_currentIndexChanged(int index)
{
    ui->plot_clearFlagEdit->setVisible(index != 0);
    if(index == 0)
        plotClearFlag.clear();
    else if(index == 1)
        plotClearFlag = ui->plot_clearFlagEdit->text();
    else if(index == 2)
        plotClearFlag = QByteArray::fromHex(ui->plot_clearFlagEdit->text().toLatin1());
}

void PlotTab::on_plot_clearFlagEdit_editingFinished()
{
    on_plot_clearFlagTypeBox_currentIndexChanged(ui->plot_clearFlagTypeBox->currentIndex());
}

void PlotTab::on_plot_frameSpEdit_editingFinished()
{
    on_plot_frameSpTypeBox_currentIndexChanged(ui->plot_frameSpTypeBox->currentIndex());
}

void PlotTab::on_plot_dataSpEdit_editingFinished()
{
    on_plot_dataSpTypeBox_currentIndexChanged(ui->plot_dataSpTypeBox->currentIndex());
}

void PlotTab::on_plot_XTypeBox_currentIndexChanged(int index)
{
    // Keep exactly four Y channels: 4 fields for Count/Time, 5 fields when
    // the first field is used as the X coordinate.
    if(index == 1)
    {
        ui->plot_dataNumBox->setRange(5, 5);
    }
    else
    {
        ui->plot_dataNumBox->setRange(4, 4);
    }

    for(int i = 0; i < PlotCount; ++i)
    {
        if(index == 2)
            m_plots[i]->xAxis->setTicker(plotTimeTicker);
        else
            m_plots[i]->xAxis->setTicker(plotDefaultTickers[i]);
        m_plots[i]->replot();
    }
}

void PlotTab::on_plot_plotStyleBox_currentIndexChanged(int index)
{
    for(int i = 0; i < PlotCount; ++i)
    {
        QCPGraph *graph = m_plots[i]->graph(0);
        if(index == 0)
        {
            graph->setLineStyle(QCPGraph::lsLine);
            graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssNone));
        }
        else if(index == 1)
        {
            graph->setLineStyle(QCPGraph::lsNone);
            graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle));
        }
        else if(index == 2)
        {
            graph->setLineStyle(QCPGraph::lsLine);
            graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle));
        }
        m_plots[i]->replot();
    }
}

void PlotTab::onXAxisChangedByUser(const QCPRange &newRange)
{
    QCPAxis *axis = qobject_cast<QCPAxis*>(sender());
    if(!axis)
        return;
    int index = plotIndex(axis->parentPlot());
    if(index >= 0)
        plotXAxisWidths[index] = newRange.size();
}

void PlotTab::saveGraphProperty()
{
    if(!settings || settings->group() != "")
        return;

    QStringList nameList, colorList;
    settings->beginGroup("SerialTest_Plot");
    for(int i = 0; i < PlotCount; ++i)
    {
        QCPAbstractPlottable *graph = m_plots[i]->graph(0);
        QString graphName = graph->name();
        if(!graph->visible() && !graphName.isEmpty() && graphName[0] == '*')
            graphName = graphName.right(graphName.size() - 1);
        nameList << graphName;
        colorList << graph->pen().color().name();
    }
    settings->setValue("GraphName", nameList);
    settings->setValue("GraphColor", colorList);
    settings->setValue("FourPanelColorVersion", 1);
    settings->endGroup();
}

void PlotTab::savePlotPreference()
{
    if(!settings || settings->group() != "")
        return;
    settings->beginGroup("SerialTest_Plot");
    settings->setValue("Enabled", ui->plot_enaBox->isChecked());
    settings->setValue("Latest", ui->plot_latestBox->isChecked());
    settings->setValue("XType", ui->plot_XTypeBox->currentIndex());
    settings->setValue("DataNum", ui->plot_dataNumBox->value());
    settings->setValue("Legend", ui->plot_legendCheckBox->isChecked());
    settings->setValue("Tracer", ui->plot_tracerCheckBox->isChecked());
    settings->setValue("FrameSp_Type", ui->plot_frameSpTypeBox->currentIndex());
    settings->setValue("FrameSp_Context", ui->plot_frameSpEdit->text());
    settings->setValue("DataSp_Type", ui->plot_dataSpTypeBox->currentIndex());
    settings->setValue("DataSp_Context", ui->plot_dataSpEdit->text());
    settings->setValue("ClearF_Type", ui->plot_clearFlagTypeBox->currentIndex());
    settings->setValue("ClearF_Context", ui->plot_clearFlagEdit->text());
    settings->setValue("PlotStyle", ui->plot_plotStyleBox->currentIndex());
    settings->endGroup();
}

void PlotTab::loadPreference()
{
    const QString defaultFrameSp = "|";
    const QString defaultDataSp = ",";

    QStringList nameList, colorList;
    bool useSavedGraphColors = false;
    settings->beginGroup("SerialTest_Plot");
    if(settings->value("FrameSp_Context").toString().isEmpty())
        settings->setValue("FrameSp_Context", defaultFrameSp);
    if(settings->value("DataSp_Context").toString().isEmpty())
        settings->setValue("DataSp_Context", defaultDataSp);

    ui->plot_enaBox->setChecked(settings->value("Enabled", false).toBool());
    ui->plot_latestBox->setChecked(settings->value("Latest", false).toBool());
    ui->plot_XTypeBox->setCurrentIndex(settings->value("XType", 0).toInt());
    ui->plot_legendCheckBox->setChecked(settings->value("Legend", false).toBool());
    ui->plot_tracerCheckBox->setChecked(settings->value("Tracer", false).toBool());
    ui->plot_frameSpTypeBox->setCurrentIndex(settings->value("FrameSp_Type", 3).toInt());
    ui->plot_frameSpEdit->setText(settings->value("FrameSp_Context", defaultFrameSp).toString());
    ui->plot_dataSpTypeBox->setCurrentIndex(settings->value("DataSp_Type", 0).toInt());
    ui->plot_dataSpEdit->setText(settings->value("DataSp_Context", defaultDataSp).toString());
    ui->plot_clearFlagTypeBox->setCurrentIndex(settings->value("ClearF_Type", 1).toInt());
    ui->plot_clearFlagEdit->setText(settings->value("ClearF_Context", "cls").toString());
    ui->plot_plotStyleBox->setCurrentIndex(settings->value("PlotStyle", 0).toInt());
    colorList = settings->value("GraphColor", QStringList()).toStringList();
    nameList = settings->value("GraphName", QStringList()).toStringList();
    useSavedGraphColors = settings->value("FourPanelColorVersion", 0).toInt() >= 1;
    settings->endGroup();

    settings->beginGroup("SerialTest");
    settings->endGroup();

    // Enforce four plotted channels, independent of older one-plot preferences.
    ui->plot_dataNumBox->setRange(ui->plot_XTypeBox->currentIndex() == 1 ? 5 : 4,
                                  ui->plot_XTypeBox->currentIndex() == 1 ? 5 : 4);
    ui->plot_dataNumBox->setValue(ui->plot_XTypeBox->currentIndex() == 1 ? 5 : 4);

    on_plot_frameSpTypeBox_currentIndexChanged(ui->plot_frameSpTypeBox->currentIndex());
    on_plot_dataSpTypeBox_currentIndexChanged(ui->plot_dataSpTypeBox->currentIndex());
    on_plot_clearFlagTypeBox_currentIndexChanged(ui->plot_clearFlagTypeBox->currentIndex());
    on_plot_XTypeBox_currentIndexChanged(ui->plot_XTypeBox->currentIndex());

    for(int i = 0; i < PlotCount; ++i)
    {
        QCPGraph *graph = m_plots[i]->graph(0);
        QPen pen(kPlotColors[i]);
        pen.setWidthF(kPlotLineWidth);
        if(useSavedGraphColors && i < colorList.size())
        {
            pen.setColor(QColor(colorList[i]));
            pen.setWidthF(kPlotLineWidth);
        }
        graph->setPen(pen);
        if(i < nameList.size() && !nameList[i].isEmpty())
            graph->setName(nameList[i]);
        else
            graph->setName(QString("CH%1").arg(i + 1));
        m_plots[i]->legend->setVisible(ui->plot_legendCheckBox->isChecked());
        m_plots[i]->replot();
    }

    on_plot_plotStyleBox_currentIndexChanged(ui->plot_plotStyleBox->currentIndex());
    on_plot_tracerCheckBox_stateChanged(ui->plot_tracerCheckBox->isChecked() ? Qt::Checked : Qt::Unchecked);
}

bool PlotTab::enabled()
{
    return ui->plot_enaBox->isChecked();
}

void PlotTab::newData(const QByteArray& data)
{
    if(decoder && plotBuf)
        plotBuf->append(decoder->toUnicode(data));
}

void PlotTab::processData()
{
    if(!plotBuf || plotBuf->isEmpty())
        return;

    double currKey = 0;
    bool hasData = false;
    int framePos = -1;
    QStringList dataList;

    while((framePos = plotBuf->indexOf(plotFrameSeparator)) != -1)
    {
        hasData = true;
        dataList = plotBuf->left(framePos).split(plotDataSeparator);
        plotBuf->remove(0, framePos + plotFrameSeparator.length());
        ++plotCounter;

        if(dataList.isEmpty())
            continue;

        if(!plotClearFlag.isEmpty() && dataList[0] == plotClearFlag)
        {
            clearGraph();
        }
        else if(ui->plot_XTypeBox->currentIndex() == 0)
        {
            currKey = plotCounter;
            for(int channel = 0; channel < PlotCount && channel < dataList.size(); ++channel)
                m_plots[channel]->graph(0)->addData(currKey, toDouble(dataList[channel]));
        }
        else if(ui->plot_XTypeBox->currentIndex() == 1)
        {
            if(dataList.size() < 2)
                continue;
            currKey = toDouble(dataList[0]);
            for(int channel = 0; channel < PlotCount && channel + 1 < dataList.size(); ++channel)
                m_plots[channel]->graph(0)->addData(currKey, toDouble(dataList[channel + 1]));
        }
        else if(ui->plot_XTypeBox->currentIndex() == 2)
        {
            currKey = plotTime.msecsTo(QTime::currentTime()) / 1000.0;
            for(int channel = 0; channel < PlotCount && channel < dataList.size(); ++channel)
                m_plots[channel]->graph(0)->addData(currKey, toDouble(dataList[channel]));
        }

        QApplication::processEvents();
    }

    if(!hasData)
    {
        if(plotBuf->size() > 1024 * 1024 * 256)
        {
            qDebug() << "plotBuf full!";
            plotBuf->clear();
        }
        return;
    }

    if(ui->plot_latestBox->isChecked())
    {
        for(int channel = 0; channel < PlotCount; ++channel)
        {
            QCPAxis *xAxis = m_plots[channel]->xAxis;
            xAxis->blockSignals(true);
            xAxis->setRange(currKey, plotXAxisWidths[channel], Qt::AlignRight);
            xAxis->blockSignals(false);
            if(ui->plot_tracerCheckBox->isChecked())
                updateTracer(channel, currKey);
        }
    }

    for(int channel = 0; channel < PlotCount; ++channel)
        m_plots[channel]->replot(QCustomPlot::rpQueuedReplot);
}

void PlotTab::setDecoder(QTextDecoder *decoder)
{
    if(this->decoder != nullptr)
        delete this->decoder;
    this->decoder = decoder;
}

void PlotTab::onThemeChanged(const QString &themeName)
{
    const QStringList darkThemeList = {"qdss_dark"};
    bool isDarkTheme = darkThemeList.contains(themeName);
    for(int i = 0; i < PlotCount; ++i)
    {
        m_plots[i]->setDarkStyle(isDarkTheme);
        m_plotTexts[i]->setPen(QPen(isDarkTheme ? Qt::white : Qt::black));
        m_plots[i]->replot();
    }
}

void PlotTab::onClearBehaviorChanged(bool clearBoth)
{
    acceptClearSignal = clearBoth;
}

void PlotTab::onClearSignalReceived()
{
    if(acceptClearSignal)
        clearGraph();
}

QCPAbstractLegendItem* PlotTab::getLegendItemByPos(QCustomPlot *plot, const QPointF &pos)
{
    if(!plot || !plot->legend->visible())
        return nullptr;
    if(plot->legend->selectTest(pos, false) == -1.0)
        return nullptr;
    for(int i = 0; i < plot->legend->itemCount(); ++i)
    {
        QCPAbstractLegendItem* item = plot->legend->item(i);
        if(item->selectTest(pos, false) != -1.0)
            return item;
    }
    return nullptr;
}

void PlotTab::setGraphProperty(QCustomPlot *plot, QCPAbstractLegendItem *item)
{
    if(!plot || !item)
        return;
    QCPPlottableLegendItem *plItem = qobject_cast<QCPPlottableLegendItem*>(item);
    if(!plItem)
        return;
    QCPAbstractPlottable* pl = plItem->plottable();
    QString oldName = pl->name();
    if(!pl->visible() && !oldName.isEmpty() && oldName[0] == '*')
        oldName = oldName.right(oldName.size() - 1);

    LegendItemDialog dialog(oldName, pl->pen().color());
    if(dialog.exec() == QDialog::Accepted)
    {
        pl->setName((pl->visible() ? "" : "*") + dialog.getName());
        QPen pen(dialog.getColor());
        pen.setWidthF(kPlotLineWidth);
        pl->setPen(pen);
        plot->replot();
        saveGraphProperty();
    }
}

inline double PlotTab::toDouble(const QString& str)
{
    return doubleRegex->match(str).captured().toDouble();
}
