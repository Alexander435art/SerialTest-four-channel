#ifndef PLOTTAB_H
#define PLOTTAB_H

#include <QWidget>
#include <QMap>
#include <QSharedPointer>
#include <QTime>
#include <QRegularExpression>
#include <QTextDecoder>
#include <QTimer>

#include "mysettings.h"
#include "mycustomplot.h"

namespace Ui
{
class PlotTab;
}

class QGroupBox;

class PlotTab : public QWidget
{
    Q_OBJECT

public:
    explicit PlotTab(QWidget *parent = nullptr);
    ~PlotTab();

    void initQCP();
    void initSettings();
    void setReplotInterval(int msec);
    bool enabled();

public slots:
    void newData(const QByteArray &data);
    void setDecoder(QTextDecoder* decoder);
    void onThemeChanged(const QString& themeName);
    void onClearBehaviorChanged(bool clearBoth);
    void onClearSignalReceived();

signals:
    void clearRxData();

private slots:
    void onQCPLegendDoubleClick(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent* event);
    void onQCPLegendClick(QCPLegend *legend, QCPAbstractLegendItem *item, QMouseEvent *event);
    void onQCPAxisDoubleClick(QCPAxis *axis);
    void onQCPMousePress(QMouseEvent *event);
    void onQCPMouseRelease(QMouseEvent *event);
    void onQCPMouseMoved(QMouseEvent *event);
    void onXAxisChangedByUser(const QCPRange &newRange);
    void on_plot_tracerCheckBox_stateChanged(int arg1);
    void on_plot_fitXButton_clicked();
    void on_plot_fitYButton_clicked();
    void on_plot_dataNumBox_valueChanged(int arg1);
    void on_plot_clearButton_clicked();
    void on_plot_legendCheckBox_stateChanged(int arg1);
    void on_plot_advancedBox_stateChanged(int arg1);
    void on_plot_frameSpTypeBox_currentIndexChanged(int index);
    void on_plot_dataSpTypeBox_currentIndexChanged(int index);
    void on_plot_plotStyleBox_currentIndexChanged(int index);
    void on_plot_frameSpEdit_editingFinished();
    void on_plot_dataSpEdit_editingFinished();
    void on_plot_clearFlagTypeBox_currentIndexChanged(int index);
    void on_plot_clearFlagEdit_editingFinished();
    void on_plot_XTypeBox_currentIndexChanged(int index);
    void savePlotPreference();
    void loadPreference();
    void processData();

private:
    static const int PlotCount = 4;

    Ui::PlotTab *ui;
    QWidget *m_plotGridWidget = nullptr;
    QGroupBox *m_plotGroups[PlotCount] = {nullptr, nullptr, nullptr, nullptr};
    MyCustomPlot *m_plots[PlotCount] = {nullptr, nullptr, nullptr, nullptr};
    QCPItemTracer *m_plotTracers[PlotCount] = {nullptr, nullptr, nullptr, nullptr};
    QCPItemText *m_plotTexts[PlotCount] = {nullptr, nullptr, nullptr, nullptr};

    QString* plotBuf = nullptr;
    qint64 plotCounter = 0;
    QString plotFrameSeparator;
    QString plotDataSeparator;
    QString plotClearFlag;
    double plotXAxisWidths[PlotCount] = {10.0, 10.0, 10.0, 10.0};
    QSharedPointer<QCPAxisTickerTime> plotTimeTicker = QSharedPointer<QCPAxisTickerTime>(new QCPAxisTickerTime);
    QSharedPointer<QCPAxisTicker> plotDefaultTickers[PlotCount];
    QTime plotTime;

    QMap<QCPAbstractLegendItem*, ulong> longPressCounter;

    QTextDecoder* decoder = nullptr;
    MySettings *settings = nullptr;
    QRegularExpression* doubleRegex = nullptr;

    QTimer* m_dataProcessTimer = nullptr;
    bool acceptClearSignal = false;

    int plotIndex(QCustomPlot *plot) const;
    QCustomPlot *plotFromSender() const;
    void updateTracer(int index, double x);
    QCPAbstractLegendItem *getLegendItemByPos(QCustomPlot *plot, const QPointF &pos);
    void setGraphProperty(QCustomPlot *plot, QCPAbstractLegendItem *item);
    inline double toDouble(const QString& str);
    void saveGraphProperty();
    void changeGraphNum(int newNum);
    void clearGraph();
};

#endif // PLOTTAB_H
